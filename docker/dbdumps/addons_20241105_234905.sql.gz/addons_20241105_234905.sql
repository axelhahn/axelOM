-- MariaDB dump 10.19  Distrib 10.5.9-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: addons
-- ------------------------------------------------------
-- Server version	10.5.9-MariaDB-1:10.5.9+maria~focal

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `objaddons`
--

DROP TABLE IF EXISTS `objaddons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objaddons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timecreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `timeupdated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted` int(11) DEFAULT NULL,
  `label` varchar(32) DEFAULT NULL,
  `version` varchar(32) DEFAULT NULL,
  `product` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `author` varchar(32) DEFAULT NULL,
  `url_website` varchar(1024) DEFAULT NULL,
  `url_docs` varchar(1024) DEFAULT NULL,
  `image_main` int(11) DEFAULT NULL,
  `description` varchar(2046) DEFAULT NULL,
  `requirements` varchar(1024) DEFAULT NULL,
  `installation` varchar(4096) DEFAULT NULL,
  `configuration` varchar(4096) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objaddons`
--

LOCK TABLES `objaddons` WRITE;
/*!40000 ALTER TABLE `objaddons` DISABLE KEYS */;
INSERT INTO `objaddons` VALUES (1,'2024-05-04 08:33:28','2024-05-06 21:37:30',0,'Dark Theme',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'2024-05-05 20:56:31','2024-05-08 21:12:18',0,'bla',NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `objaddons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objaddontypes`
--

DROP TABLE IF EXISTS `objaddontypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objaddontypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timecreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `timeupdated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted` int(11) DEFAULT NULL,
  `label` varchar(32) DEFAULT NULL,
  `image_main` int(11) DEFAULT NULL,
  `description` varchar(4096) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objaddontypes`
--

LOCK TABLES `objaddontypes` WRITE;
/*!40000 ALTER TABLE `objaddontypes` DISABLE KEYS */;
INSERT INTO `objaddontypes` VALUES (1,'2024-05-04 08:32:50','2024-08-14 21:15:44',0,'Icons',NULL,''),(2,'2024-05-04 08:32:58','2024-08-14 21:16:06',0,'Theme',NULL,''),(3,'2024-05-04 08:33:05','2024-08-14 14:53:08',0,'Plugins',NULL,NULL);
/*!40000 ALTER TABLE `objaddontypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objproducts`
--

DROP TABLE IF EXISTS `objproducts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objproducts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timecreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `timeupdated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted` int(11) DEFAULT NULL,
  `label` varchar(32) DEFAULT NULL,
  `description` varchar(4096) DEFAULT NULL,
  `date_release` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `image_main` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objproducts`
--

LOCK TABLES `objproducts` WRITE;
/*!40000 ALTER TABLE `objproducts` DISABLE KEYS */;
INSERT INTO `objproducts` VALUES (1,'2023-11-16 21:57:22','2024-04-25 20:12:20',0,'Ah Crawler',NULL,'2024-08-14 21:47:33',NULL),(3,'2024-05-12 10:08:04','2024-08-14 21:47:33',0,'Pimped Apache Status',NULL,'2024-08-14 21:47:33',NULL),(4,'2024-05-18 22:14:10','2024-08-14 21:48:26',0,'AMC Player','','2024-08-14 21:47:33',NULL);
/*!40000 ALTER TABLE `objproducts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objprogramminglanguages`
--

DROP TABLE IF EXISTS `objprogramminglanguages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objprogramminglanguages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timecreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `timeupdated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted` int(11) DEFAULT NULL,
  `label` varchar(32) DEFAULT NULL,
  `description` varchar(4096) DEFAULT NULL,
  `url` varchar(1024) DEFAULT NULL,
  `license` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objprogramminglanguages`
--

LOCK TABLES `objprogramminglanguages` WRITE;
/*!40000 ALTER TABLE `objprogramminglanguages` DISABLE KEYS */;
INSERT INTO `objprogramminglanguages` VALUES (1,'2023-11-16 21:56:38','2024-08-14 14:23:49',0,'PHP','','',''),(2,'2023-11-16 21:56:47','2024-08-14 14:23:49',0,'Javascript','','',''),(3,'2023-11-16 21:57:04','2024-04-25 21:36:21',0,'Bash','','','');
/*!40000 ALTER TABLE `objprogramminglanguages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdo_db_attachments`
--

DROP TABLE IF EXISTS `pdo_db_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdo_db_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timecreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `timeupdated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted` int(11) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `mime` varchar(32) DEFAULT NULL,
  `description` varchar(2048) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdo_db_attachments`
--

LOCK TABLES `pdo_db_attachments` WRITE;
/*!40000 ALTER TABLE `pdo_db_attachments` DISABLE KEYS */;
INSERT INTO `pdo_db_attachments` VALUES (1,'2023-11-16 22:03:09','2024-08-14 14:23:49',0,'cronlogviewer_all_servers.png','image/png','',312039,NULL,NULL);
/*!40000 ALTER TABLE `pdo_db_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdo_db_relations`
--

DROP TABLE IF EXISTS `pdo_db_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdo_db_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timecreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `timeupdated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted` int(11) DEFAULT NULL,
  `from_table` varchar(32) DEFAULT NULL,
  `from_id` int(11) DEFAULT NULL,
  `from_column` varchar(32) DEFAULT NULL,
  `to_table` varchar(32) DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  `to_column` varchar(32) DEFAULT NULL,
  `uuid` text NOT NULL,
  `remark` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdo_db_relations`
--

LOCK TABLES `pdo_db_relations` WRITE;
/*!40000 ALTER TABLE `pdo_db_relations` DISABLE KEYS */;
INSERT INTO `pdo_db_relations` VALUES (1,'2023-11-16 21:57:39','2024-08-14 21:47:33',0,'objproducts',1,NULL,'objprogramminglanguages',1,NULL,'5b3bdab5e9179a4ed79d98dfc5c5f0cd',NULL),(2,'2023-11-16 22:03:09','2024-08-14 21:47:33',0,'objproducts',1,NULL,'pdo_db_attachments',1,NULL,'efbfc06787701c058739d2a2f720e12b',NULL),(4,'2024-05-05 20:56:31','2024-08-14 21:47:33',0,'objaddons',2,'type','objaddontypes',2,NULL,'27bcc7d0e9be7a2af7b0bfda6b135eff',NULL),(5,'2024-05-06 21:37:30','2024-08-14 21:47:33',0,'objaddons',1,'product','objproducts',1,NULL,'0cf7230d8c38ba521ce648cc5b25b952',NULL),(6,'2024-05-06 21:37:30','2024-08-14 21:47:33',0,'objaddons',1,'type','objaddontypes',2,NULL,'766a213028907b8beeeae950274f528e',NULL),(10,'2024-05-12 10:08:27','2024-08-14 21:47:33',0,'objproducts',3,NULL,'objprogramminglanguages',1,NULL,'7b4a046a1179fc703effc51952cd4cd7',NULL),(13,'2024-05-18 22:50:49','2024-08-14 21:47:33',0,'objproducts',4,NULL,'objprogramminglanguages',2,NULL,'55650de80da001c2754334c531ef4f1a',NULL),(14,'2024-06-09 21:20:34','2024-08-14 21:47:33',0,'objaddons',1,NULL,'objproducts',1,NULL,'c8124ba6d1255c0f620d4cd775db8027',NULL);
/*!40000 ALTER TABLE `pdo_db_relations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-05 22:49:05
